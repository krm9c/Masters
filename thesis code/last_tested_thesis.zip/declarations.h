// //
// //  declarations.h
// //  Opencv Motion Library
// //
// //  Created by Krishnan Raghavan on 5/1/14.
// //  Copyright (c) 2014 Krishnan Raghavan. All rights reserved.
// /
// // Header file Declarations
#include <ctime>
#include <iostream>
#include <stdio.h>
#include <vector>
#include <list>
#include <pcl/surface/gp3.h>
#include <pcl/features/normal_3d.h>
#include <pcl/io/vtk_io.h>
#include <pcl/search/kdtree.h>
//#include "capture.h"
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <getopt.h>            
#include <fcntl.h>              
#include <unistd.h>
#include <errno.h>
#include <iomanip>
#include <math.h>
//#include </opencv/cxcore.hpp>
#include <opencv2/opencv.hpp>
#include <map>
#include <cvaux.h>
#include <cv.h>
#include <cxcore.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/nonfree/features2d.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/nonfree/nonfree.hpp>





//#include "/opencv2/core/core.hpp"
//#include </opencv2/imgproc/imgproc.hpp>
//#include </opencv2/highgui/highgui.h>
//#include </opencv2/features2d/features2d.h>
//#include <stdio.h>
//#include <iostream>
//#include <opencv2/core/core.hpp>
//#include <opencv2/features2d/features2d.hpp>
//#include <opencv2/nonfree/features2d.hpp>
//#include <opencv2/highgui/highgui.hpp>
//#include "opencv2/nonfree/nonfree.hpp"
#include <pcl/common/common_headers.h>
#include <pcl/io/pcd_io.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <boost/thread/thread.hpp>

/***********************************************************
///Declaration of Namespaces
************************************************************/

 using namespace std ;
 using namespace cv  ;

/************************************************************
 Structure to define and store the images
 Usage : ImageMat I
*************************************************************/
struct ImageMat{
       Mat img                   ;
       int number_points_detected;
       ImageMat(){
        number_points_detected=0;
       }
};
/************************************************************
 Datatype/structures to store three coordinates of a point coming out of an image
 Usage through point (refer point)
**************************************************************/
struct coordinates{
    float x ;
    float y ;
    float z ;
    coordinates(){
        x=0.0   ;
        y=0.0   ;
        z=0.0   ;
    }
};
/****************************************************************
 for storing the colors
 Usage :  through the object Point (refer point )
******************************************************************/
struct RGB{
    int R ;
    int G ;
    int B ;
    RGB (){
        R=0 ;
        G=0 ;
        B=0 ;
    }
};
/********************************************************************************
 vertex storing the colors and  the point coordinates
 Usage : declare an object by the name point
 point P ;
 to enter data use like P.P.x and similarly
 Made in a heirarchical structure
*********************************************************************************/

struct point{
    string   label;
    time_t      t ; 
    coordinates P ;
    RGB         C ;
};

// structure to store the lines

struct lines{
point vertex;
lines *next  ;
};

/*********************************************************************************
  Maps/Associative Arrays to store all the data


    1. associative array for images :  Images_List
            Two Dimensional array , so keys are of two type
                                        1. point no.
                                        2. time stamp

    2. Associative array for points :  Points_List
          Two Dimensional array , so keys are of two type
                                      1. Image name (orginal , wireframe etc .)
                                      2. time stamp
  Arrays to store all the keys
***********************************************************************************/
struct I_List{
map < pair<string , time_t>, ImageMat> Images_List;
std::vector<std::string>   keyouterImages ;// Store rhis key becaus this is what is gonna help us identify points. 
vector<time_t>   keytimeImages  ;   
};


struct P_List{
map < pair<string , time_t>, point   > Points_List;
vector<string>   keyouterPoints ;// Store rhis key becaus this is what is gonna help us identify points. 
vector<time_t>   keytimePoints  ;  
};


struct L_List{
map < pair<string , time_t>, lines*   > Lines_List ;
vector<string>   keyouterLines ;// Store rhis key becaus this is what is gonna help us identify points. 
vector<time_t>   keytimeLines  ;  
};

# define EPSILON 0.00001 


int labelno=0;
struct M_List{
map < time_t , Matx34d > TrackMotion ; 
vector<time_t>   keytimemotion       ;  
}; 

std::vector<point>       coordinates_list;
/*****************************************************************************
Calculating the distortion and camera parameters
Another file names calib.cpp consists of the camera callibration matrix and are called and stored into the matrices  here 
****************************************************************************/


struct CloudPoint {
  cv::Point3d pt;
  std::vector<int> imgpt_for_img;
  double reprojection_error;
};


Mat       CameraMatrix , distortion ;

Mat       cameracalibration( Mat &distortion);
/*****************************************************************************

This one is a temporary structure to work with the point cloud library . BAsically for visualisation.


******************************************************************************/








/*****************************************************************************



******************************************************************************/



ImageMat *thresholdRGB(ImageMat* Iparameter ,coordinates Cthreshold ,RGB RGBthreshold, string key,I_List I_object);

ImageMat *imageconvertgrayscale(ImageMat *I);

ImageMat *PrelimEdgeDetection(ImageMat *Isrc , string key , I_List &I_object);

ImageMat retreiveimages( I_List &I , time_t t , string key);

lines *retreivelines(L_List &L ,time_t t , string key);

point retreivepoints(P_List &P, time_t t , string key);

void eraselines(L_List &L , time_t t , string key);

void storemotion(map < time_t , Matx34d > TrackMotion , Matx34d P );

void erasepoints(P_List &P , time_t t , string key);

void eraseimages(I_List &I , time_t t , string key);

void  storelines(L_List &L , lines l , string key );

void  storepoints(P_List &P ,point *p, string key );

void storeimage(I_List &I ,ImageMat M , string key );

void Display_All_Keys_string(list<string> L);

void Display_All_Keys_time(list<time_t> L);

int comparepoints(lines *temp,lines *temp1);

void storemotion(M_List &M , Matx34d P );

point *convertcloudPointtopoint(point *temppoint , vector<CloudPoint> outCloud);

Matx34d retreivemotion(M_List &M , time_t t);

void remove(vector<time_t> & v, time_t & item);

void remove(vector<string> & v, string & item);

void erasemotion(M_List &M, time_t t );


void *printlines(lines *start);


lines *convert(point *V);

Mat Display_Points_onImage(point *Vertexes , Mat im_bw1 );

ImageMat *VerticesDetection(ImageMat *I , string key , P_List &P_ob , L_List &L_ob ,I_List &I_ob );

point *assignlabels(point *V);

void       matches2points(const vector<KeyPoint>& train, 
           const vector<KeyPoint>& query,
           const std::vector<cv::DMatch>& mtches, 
           std::vector<cv::Point2f>& pts_train,
           std::vector<Point2f>& pts_query);

void       PointsToKeypoints(const vector<Point2f>& in, vector<KeyPoint>& out);

void       KeypointsToPoints(const vector<KeyPoint>& in, vector<Point2f>& out);

void       GetAlignedPointsFromMatch(const std::vector<cv::KeyPoint>& imgpts1,
                                     const std::vector<cv::KeyPoint>& imgpts2,
                                     const std::vector<cv::DMatch>& matches,
                                     std::vector<cv::KeyPoint>& pt_set1,
                                     std::vector<cv::KeyPoint>& pt_set2) ;

void        TakeSVDOfE(Mat_<double>& E, Mat& svd_u, Mat& svd_vt, Mat& svd_w);

bool        DecomposeEssentialUsingHorn90(double _E[9], double _R1[9], double _R2[9], double _t1[3], double _t2[3]) ;

bool        DecomposeEtoRandT( Mat_<double>& E,
                               Mat_<double>& R1,
                               Mat_<double>& R2,
                               Mat_<double>& t1,
                               Mat_<double>& t2) ;



double      TriangulatePoints(const vector<KeyPoint>& pt_set1, 
                              const vector<KeyPoint>& pt_set2, 
                              const Mat& K,
                              const Mat& Kinv,
                              const Mat& distcoeff,
                              const Matx34d& P,
                              const Matx34d& P1,
                              vector<CloudPoint>& pointcloud,
                              vector<KeyPoint>& correspImg1Pt);

bool        CheckCoherentRotation(cv::Mat_<double>& R) ;

bool        TestTriangulation(const vector<CloudPoint>& pcloud, const Matx34d& P, vector<uchar>& status) ;// change in the original function

Mat         GetFundamentalMat( const vector<KeyPoint>& imgpts1,
                               const vector<KeyPoint>& imgpts2,
                               vector<KeyPoint>& imgpts1_good,
                               vector<KeyPoint>& imgpts2_good,
                               vector<DMatch>& matches );

int  CalculateMotionMap(Mat  img_1  , 
                        Mat   img_2 , 
                        vector<KeyPoint> &keypoints_1 , 
                        vector<KeyPoint> &keypoints_2 ,
                        vector<KeyPoint>& fullpts1,
                        vector<KeyPoint>& fullpts2,
                        vector<KeyPoint> &imgpts1_good,
                        vector<KeyPoint> &imgpts2_good,
                        vector <DMatch>  &matches);

bool         FindCameraMatrices(const Mat& K, 
                                const Mat& Kinv, 
                                const Mat& distcoeff,
                                const vector<KeyPoint>& imgpts1,
                                const vector<KeyPoint>& imgpts2,
                                vector<KeyPoint>& imgpts1_good,
                                vector<KeyPoint>& imgpts2_good,
                                Matx34d& P,
                                Matx34d& P1,
                                vector<DMatch>& matches
                                );

Mat_<double> LinearLSTriangulation(Point3d u,       //homogenous image point (u,v,1)
                                   Matx34d P,       //camera 1 matrix
                                   Point3d u1,      //homogenous image point in 2nd camera
                                   Matx34d P1       //camera 2 matrix
                                   ) ;

Mat_<double> IterativeLinearLSTriangulation(Point3d u,  //homogenous image point (u,v,1)
                                            Matx34d P,          //camera 1 matrix
                                            Point3d u1,         //homogenous image point in 2nd camera
                                            Matx34d P1          //camera 2 matrix
                                            );


point       *Recoverpoint( vector<CloudPoint>& pointcloud  , point *P);

void        visualization( pcl::PointCloud<pcl::PointXYZ>::Ptr source_cloud , pcl::PointCloud<pcl::PointXYZ>::Ptr transformed_cloud);

Mat         Imagetomat(string filename );

ImageMat     *ImageAcquisition(int choice , string filename , string key , I_List &I_object);
pcl::PointCloud<pcl::PointXYZ>::Ptr convertintopointcloud(point *p , pcl::PointCloud<pcl::PointXYZ>::Ptr cloud ,int size);
